#include "minifyjpeg.h"
#include "magickminify.h"

/* Implement the needed server-side functions here */
